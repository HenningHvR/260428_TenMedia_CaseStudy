<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Kategorie anzeigen
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Kategorie anzeigen
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="mb-4 flex items-center gap-4">
                <a
                    href="<?php echo e(route('categories.index')); ?>"
                    class="text-sm text-gray-600 hover:text-gray-900"
                >
                    Zurück zur Übersicht
                </a>

                <a
                    href="<?php echo e(route('categories.edit', $category)); ?>"
                    class="text-sm text-blue-600 hover:text-blue-900"
                >
                    Kategorie bearbeiten
                </a>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900">

                    <h3 class="text-lg font-semibold mb-4">
                        <?php echo e($category->ctgry_name); ?>

                    </h3>

                    <div class="mb-4">
                        <p class="text-sm font-medium text-gray-700">
                            Beschreibung
                        </p>

                        <p class="mt-1 text-gray-900">
                            <?php echo e($category->ctgry_description ?? 'Keine Beschreibung hinterlegt.'); ?>

                        </p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                        <div>
                            <p class="text-sm font-medium text-gray-700">
                                Erstellt am
                            </p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($category->created_at?->format('d.m.Y H:i') ?? 'Keine Angabe'); ?>

                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">
                                Zuletzt geändert am
                            </p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($category->updated_at?->format('d.m.Y H:i') ?? 'Keine Angabe'); ?>

                            </p>
                        </div>
                    </div>

                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <h3 class="text-lg font-semibold mb-4">
                        Zugeordnete JobPostings
                    </h3>

                    <?php if($category->jobPostings->isEmpty()): ?>
                        <p>
                            Dieser Kategorie sind noch keine JobPostings zugeordnet.
                        </p>
                    <?php else: ?>
                        <table class="min-w-full border border-gray-300">
                            <thead>
                            <tr class="bg-gray-100">
                                <th class="border px-4 py-2 text-left">Titel</th>
                                <th class="border px-4 py-2 text-left">Company</th>
                                <th class="border px-4 py-2 text-left">Ort</th>
                                <th class="border px-4 py-2 text-left">Status</th>
                                <th class="border px-4 py-2 text-left">Aktion</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $category->jobPostings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobPosting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->title); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->company->cmpny_name ?? 'Keine Company'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->jp_location ?? 'Keine Angabe'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php if($jobPosting->is_active): ?>
                                            Aktiv
                                        <?php else: ?>
                                            Inaktiv
                                        <?php endif; ?>
                                    </td>

                                    <td class="border px-4 py-2">
                                        <a
                                            href="<?php echo e(route('job-postings.show', $jobPosting)); ?>"
                                            class="text-blue-600 hover:text-blue-900"
                                        >
                                            JobPosting anzeigen
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/categories/show.blade.php ENDPATH**/ ?>