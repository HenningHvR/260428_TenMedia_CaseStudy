<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        JobPosting anzeigen
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            JobPosting anzeigen
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <div class="mb-6">
                        <h3 class="text-lg font-semibold">
                            <?php echo e($jobPosting->title); ?>

                        </h3>

                        <p class="mt-2 text-gray-700">
                            <?php echo e($jobPosting->jp_description ?? 'Keine Beschreibung hinterlegt.'); ?>

                        </p>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                            <p class="text-sm font-medium text-gray-700">Firma</p>

                            <p class="mt-1 text-gray-900">
                                <?php if($jobPosting->company): ?>
                                    <a
                                        href="<?php echo e(route('companies.show', $jobPosting->company)); ?>"
                                        class="text-blue-600 hover:underline"
                                    >
                                        <?php echo e($jobPosting->company->cmpny_name); ?>

                                    </a>
                                <?php else: ?>
                                    Keine Firma zugeordnet
                                <?php endif; ?>
                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Kategorie</p>

                            <p class="mt-1 text-gray-900">
                                <?php if($jobPosting->category): ?>
                                    <a
                                        href="<?php echo e(route('categories.show', $jobPosting->category)); ?>"
                                        class="text-blue-600 hover:underline"
                                    >
                                        <?php echo e($jobPosting->category->ctgry_name); ?>

                                    </a>
                                <?php else: ?>
                                    Keine Kategorie zugeordnet
                                <?php endif; ?>
                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Ort</p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($jobPosting->jp_location ?? 'Keine Angabe'); ?>

                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Erfahrungslevel</p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($jobPosting->experience_level ?? 'Keine Angabe'); ?>

                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Arbeitszeit</p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($jobPosting->employment_type ?? 'Keine Angabe'); ?>

                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Gehalt</p>

                            <p class="mt-1 text-gray-900 whitespace-nowrap">
                                <?php if($jobPosting->salary): ?>
                                    <?php echo e(number_format($jobPosting->salary, 0, ',', '.')); ?>&nbsp;€
                                <?php else: ?>
                                    Keine Angabe
                                <?php endif; ?>
                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Status</p>

                            <p class="mt-1 text-gray-900">
                                <?php if($jobPosting->is_active): ?>
                                    Aktiv
                                <?php else: ?>
                                    Inaktiv
                                <?php endif; ?>
                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Erstellt am</p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($jobPosting->created_at?->format('d.m.Y H:i') ?? 'Keine Angabe'); ?>

                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-medium text-gray-700">Zuletzt geändert am</p>

                            <p class="mt-1 text-gray-900">
                                <?php echo e($jobPosting->updated_at?->format('d.m.Y H:i') ?? 'Keine Angabe'); ?>

                            </p>
                        </div>
                    </div>

                    <div class="flex items-center gap-4">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $jobPosting)): ?>
                            <a
                                href="<?php echo e(route('job-postings.edit', $jobPosting)); ?>"
                                class="px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700"
                            >
                                Bearbeiten
                            </a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $jobPosting)): ?>
                            <form
                                method="POST"
                                action="<?php echo e(route('job-postings.destroy', $jobPosting)); ?>"
                                onsubmit="return confirm('Dieses JobPosting wirklich löschen?');"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button
                                    type="submit"
                                    class="px-4 py-2 bg-red-700 text-white rounded-md hover:bg-red-600"
                                >
                                    Löschen
                                </button>
                            </form>
                        <?php endif; ?>

                        <a
                            href="<?php echo e(route('job-postings.index')); ?>"
                            class="text-sm text-gray-600 hover:text-gray-900"
                        >
                            Zurück zur Übersicht
                        </a>
                    </div>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/job_postings/show.blade.php ENDPATH**/ ?>