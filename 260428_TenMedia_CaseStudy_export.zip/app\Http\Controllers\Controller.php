<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

abstract class Controller
{
    // Bereitstellung der Methode $this->authorize(...) für alle Controller.
    use AuthorizesRequests;
}
