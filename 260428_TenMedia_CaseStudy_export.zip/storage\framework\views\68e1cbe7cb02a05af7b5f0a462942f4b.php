<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Dashboard
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-y-6">

                
                <a
                    href="<?php echo e(route('categories.index')); ?>"
                    class="block bg-white overflow-hidden shadow-sm sm:rounded-lg hover:bg-gray-50"
                >
                    <div class="p-6 text-center text-gray-900 font-semibold text-lg">
                        Kategorien
                    </div>
                </a>

                
                <a
                    href="<?php echo e(route('companies.index')); ?>"
                    class="block bg-white overflow-hidden shadow-sm sm:rounded-lg hover:bg-gray-50"
                >
                    <div class="p-6 text-center text-gray-900 font-semibold text-lg">
                        Firmen
                    </div>
                </a>

                
                <a
                    href="<?php echo e(route('job-postings.index')); ?>"
                    class="block bg-white overflow-hidden shadow-sm sm:rounded-lg hover:bg-gray-50"
                >
                    <div class="p-6 text-center text-gray-900 font-semibold text-lg">
                        JobPostings
                    </div>
                </a>

                
                <?php if(auth()->user()?->role === 'admin'): ?>
                    <a
                        href="<?php echo e(route('users.index')); ?>"
                        class="block bg-white overflow-hidden shadow-sm sm:rounded-lg hover:bg-gray-50"
                    >
                        <div class="p-6 text-center text-gray-900 font-semibold text-lg">
                            User
                        </div>
                    </a>
                <?php endif; ?>

            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>