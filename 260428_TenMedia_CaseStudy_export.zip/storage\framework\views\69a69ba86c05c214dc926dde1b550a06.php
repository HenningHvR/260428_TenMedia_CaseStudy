<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Firmen anzeigen
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Firmen anzeigen
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="mb-4 flex items-center gap-4">
                <a
                    href="<?php echo e(route('dashboard')); ?>"
                    class="inline-block px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
                >
                    Zurück zum Dashboard
                </a>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Company::class)): ?>
                    <a
                        href="<?php echo e(route('companies.create')); ?>"
                        class="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                        Neue Firma anlegen
                    </a>
                <?php endif; ?>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <?php if($companies->isEmpty()): ?>
                        <p>
                            Es wurden noch keine Firmen angelegt.
                        </p>
                    <?php else: ?>
                        <table class="min-w-full border border-gray-300">
                            <thead>
                            <tr class="bg-gray-100">
                                <th class="border px-4 py-2 text-left">
                                    Firma
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    Beschreibung
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    Website
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    Standort
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    Provider
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    JobPostings
                                </th>

                                <th class="border px-4 py-2 text-left">
                                    Aktionen
                                </th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2">
                                        <?php echo e($company->cmpny_name); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($company->cmpny_description ?? 'Keine Beschreibung'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php if($company->website): ?>
                                            <a
                                                href="<?php echo e(str_starts_with($company->website, 'http') ? $company->website : 'https://' . $company->website); ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                class="text-blue-600 hover:underline"
                                            >
                                                <?php echo e($company->website); ?>

                                            </a>
                                        <?php else: ?>
                                            Keine Website
                                        <?php endif; ?>
                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($company->cmpny_location ?? 'Keine Angabe'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php if($company->providers->isEmpty()): ?>
                                            Keine Provider
                                        <?php else: ?>
                                            <?php echo e($company->providers->pluck('name')->join(', ')); ?>

                                        <?php endif; ?>
                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($company->job_postings_count); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <a
                                            href="<?php echo e(route('companies.show', $company)); ?>"
                                            class="text-blue-600 hover:underline"
                                        >
                                            Anzeigen
                                        </a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $company)): ?>
                                            <span class="mx-1">|</span>

                                            <a
                                                href="<?php echo e(route('companies.edit', $company)); ?>"
                                                class="text-blue-600 hover:underline"
                                            >
                                                Bearbeiten
                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $company)): ?>
                                            <?php if($company->job_postings_count === 0 && $company->providers->isEmpty()): ?>
                                                <span class="mx-1">|</span>

                                                <form
                                                    action="<?php echo e(route('companies.destroy', $company)); ?>"
                                                    method="POST"
                                                    class="inline"
                                                >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <button
                                                        type="submit"
                                                        class="text-red-600 hover:underline"
                                                        onclick="return confirm('Diese Firma wirklich löschen?')"
                                                    >
                                                        Löschen
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/companies/index.blade.php ENDPATH**/ ?>