<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        JobPosting
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            JobPostings
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="mb-4">
                <a href="<?php echo e(route('job-postings.create')); ?>"
                   class="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Neues JobPosting anlegen
                </a>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <?php if($jobPostings->isEmpty()): ?>
                        <p>Es wurden noch keine JobPostings angelegt.</p>
                    <?php else: ?>
                        <table class="min-w-full border border-gray-300">
                            <thead>
                            <tr class="bg-gray-100">
                                <th class="border px-4 py-2 text-left">Titel</th>
                                <th class="border px-4 py-2 text-left">Firma</th>
                                <th class="border px-4 py-2 text-left">Kategorie</th>
                                <th class="border px-4 py-2 text-left">Ort</th>
                                <th class="border px-4 py-2 text-left">Erfahrungslevel</th>
                                <th class="border px-4 py-2 text-left">Arbeitszeit</th>
                                <th class="border px-4 py-2 text-left">Gehalt</th>
                                <th class="border px-4 py-2 text-left">Status</th>
                                <th class="border px-4 py-2 text-left">Aktionen</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $jobPostings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobPosting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->title); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->company->cmpny_name ?? 'Keine Company'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->category->ctgry_name ?? 'Keine Kategorie'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->jp_location ?? 'Keine Angabe'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->experience_level ?? 'Keine Angabe'); ?>

                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php echo e($jobPosting->employment_type ?? 'Keine Angabe'); ?>

                                    </td>

                                    <td class="border px-4 py-2 whitespace-nowrap">
                                        <?php if($jobPosting->salary): ?>
                                            <?php echo e(number_format($jobPosting->salary, 0, ',', '.')); ?>&nbsp;€
                                        <?php else: ?>
                                            Keine Angabe
                                        <?php endif; ?>
                                    </td>

                                    <td class="border px-4 py-2">
                                        <?php if($jobPosting->is_active): ?>
                                            Aktiv
                                        <?php else: ?>
                                            Inaktiv
                                        <?php endif; ?>
                                    </td>

                                    <td class="border px-4 py-2">
                                        <a href="<?php echo e(route('job-postings.show', $jobPosting)); ?>"
                                           class="text-blue-600 hover:underline">
                                            Anzeigen
                                        </a>

                                        <span class="mx-1">|</span>

                                        <a href="<?php echo e(route('job-postings.edit', $jobPosting)); ?>"
                                           class="text-blue-600 hover:underline">
                                            Bearbeiten
                                        </a>

                                        <span class="mx-1">|</span>

                                        <form action="<?php echo e(route('job-postings.destroy', $jobPosting)); ?>"
                                              method="POST"
                                              class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit"
                                                    class="text-red-600 hover:underline"
                                                    onclick="return confirm('Dieses JobPosting wirklich löschen?')">
                                                Löschen
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/job_postings/index.blade.php ENDPATH**/ ?>